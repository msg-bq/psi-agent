```fusionflow
-- SCENARIO: approval workflow with full parallel handlers and conditional output
-- AUTHORED: from intent: "decision with both handlers running, selected artifact as output"

const request: Artifact;
const approved_flag: Artifact;
const approved_artifact: Artifact;
const rejected_artifact: Artifact;
const selected_result: Artifact;

const decision_step: Step;
const approve_handler: Step;
const reject_handler: Step;

const decision_name: StepName;
const approve_name: StepName;
const reject_name: StepName;

const decision_instruction: Instruction;
const approve_instruction: Instruction;
const reject_instruction: Instruction;

const decision_agent: Agent, Executor;
const approve_agent: Agent, Executor;
const reject_agent: Agent, Executor;

workflow approval_workflow {
  -- DATA FLOW
  input_workflow(approval_workflow) == [request];
  consumes(decision_step) == [request];
  produces(decision_step) == [approved_flag];
  consumes(approve_handler) == [request];
  produces(approve_handler) == [approved_artifact];
  consumes(reject_handler) == [request];
  produces(reject_handler) == [rejected_artifact];
  selected_result == if(approved_flag = "True", approved_artifact, rejected_artifact);
  output_workflow(approval_workflow) == [selected_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(decision_step) == decision_agent;
  step_executor(approve_handler) == approve_agent;
  step_executor(reject_handler) == reject_agent;

  -- STEP CONFIGURATION
  step_name(decision_step) == decision_name;
  step_instruction(decision_step) == decision_instruction;
  step_name(approve_handler) == approve_name;
  step_instruction(approve_handler) == approve_instruction;
  step_name(reject_handler) == reject_name;
  step_instruction(reject_handler) == reject_instruction;
}
```