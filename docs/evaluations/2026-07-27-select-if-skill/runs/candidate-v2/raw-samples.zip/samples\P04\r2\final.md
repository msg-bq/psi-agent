```fusionflow
-- SCENARIO: Four-level priority routing with eager handlers and chained if selection

const request: Artifact;
const critical_flag: Artifact;
const legal_flag: Artifact;
const review_flag: Artifact;
const critical_result: Artifact;
const legal_result: Artifact;
const review_result: Artifact;
const fallback_result: Artifact;
const first_priority: Artifact;
const second_priority: Artifact;
const third_priority: Artifact;
const selected_result: Artifact;
const final_result: Artifact;

const triage_step: Step;
const critical_handler_step: Step;
const legal_handler_step: Step;
const review_handler_step: Step;
const fallback_handler_step: Step;
const final_step: Step;

const triage_name: StepName;
const critical_handler_name: StepName;
const legal_handler_name: StepName;
const review_handler_name: StepName;
const fallback_handler_name: StepName;
const final_name: StepName;

const triage_instruction: Instruction;
const critical_instruction: Instruction;
const legal_instruction: Instruction;
const review_instruction: Instruction;
const fallback_instruction: Instruction;
const final_instruction: Instruction;

const triage_agent: Agent, Executor;
const critical_handler: Agent, Executor;
const legal_handler: Agent, Executor;
const review_handler: Agent, Executor;
const fallback_handler: Agent, Executor;
const final_consumer: Agent, Executor;

const standard_model: Model;
const standard_engine: Engine;
const standard_api: ApiBase;

workflow priority_routing {
  -- DATA FLOW
  input_workflow(priority_routing) == [request];
  consumes(triage_step) == [request];
  produces(triage_step) == [critical_flag, legal_flag, review_flag];
  consumes(critical_handler_step) == [request];
  produces(critical_handler_step) == [critical_result];
  consumes(legal_handler_step) == [request];
  produces(legal_handler_step) == [legal_result];
  consumes(review_handler_step) == [request];
  produces(review_handler_step) == [review_result];
  consumes(fallback_handler_step) == [request];
  produces(fallback_handler_step) == [fallback_result];
  first_priority == if(critical_flag = True, critical_result, second_priority);
  second_priority == if(legal_flag = True, legal_result, third_priority);
  third_priority == if(review_flag = True, review_result, fallback_result);
  selected_result == first_priority;
  consumes(final_step) == [selected_result];
  produces(final_step) == [final_result];
  output_workflow(priority_routing) == [final_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(triage_step) == triage_agent;
  step_executor(critical_handler_step) == critical_handler;
  step_executor(legal_handler_step) == legal_handler;
  step_executor(review_handler_step) == review_handler;
  step_executor(fallback_handler_step) == fallback_handler;
  step_executor(final_step) == final_consumer;

  -- STEP CONFIGURATION
  step_name(triage_step) == triage_name;
  step_instruction(triage_step) == triage_instruction;
  step_name(critical_handler_step) == critical_handler_name;
  step_instruction(critical_handler_step) == critical_instruction;
  step_name(legal_handler_step) == legal_handler_name;
  step_instruction(legal_handler_step) == legal_instruction;
  step_name(review_handler_step) == review_handler_name;
  step_instruction(review_handler_step) == review_instruction;
  step_name(fallback_handler_step) == fallback_handler_name;
  step_instruction(fallback_handler_step) == fallback_instruction;
  step_name(final_step) == final_name;
  step_instruction(final_step) == final_instruction;

  -- AGENT CONFIGURATION
  agent_config(triage_agent, standard_model, standard_engine, standard_api);
  agent_config(critical_handler, standard_model, standard_engine, standard_api);
  agent_config(legal_handler, standard_model, standard_engine, standard_api);
  agent_config(review_handler, standard_model, standard_engine, standard_api);
  agent_config(fallback_handler, standard_model, standard_engine, standard_api);
  agent_config(final_consumer, standard_model, standard_engine, standard_api);
}
```