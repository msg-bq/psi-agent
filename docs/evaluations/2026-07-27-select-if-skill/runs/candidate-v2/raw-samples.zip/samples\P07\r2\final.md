```fusionflow
-- SCENARIO: request classification with primary/fallback routing via artifact selection
-- AUTHORED: from intent: "classifier Step produces preferred_flag; primary and fallback handler Steps both consume request and eagerly produce primary_result and fallback_result; final_step consumes the selected result and produces final_result"

const request: Artifact;
const preferred_flag: Artifact;
const primary_result: Artifact;
const fallback_result: Artifact;
const selected_result: Artifact;
const final_result: Artifact;

const classify_step: Step;
const primary_handler_step: Step;
const fallback_handler_step: Step;
const final_step: Step;

const classify_name: StepName;
const primary_handler_name: StepName;
const fallback_handler_name: StepName;
const final_name: StepName;

const classify_instruction: Instruction;
const primary_handler_instruction: Instruction;
const fallback_handler_instruction: Instruction;
const final_instruction: Instruction;

const classifier: Agent, Executor;
const primary_agent: Agent, Executor;
const fallback_agent: Agent, Executor;
const final_agent: Agent, Executor;

const default_model: Model;
const default_engine: Engine;
const default_api: ApiBase;

workflow request_routing {
  -- DATA FLOW
  input_workflow(request_routing) == [request];
  consumes(classify_step) == [request];
  produces(classify_step) == [preferred_flag];
  consumes(primary_handler_step) == [request];
  produces(primary_handler_step) == [primary_result];
  consumes(fallback_handler_step) == [request];
  produces(fallback_handler_step) == [fallback_result];
  selected_result == if(preferred_flag = True, primary_result, fallback_result);
  consumes(final_step) == [selected_result];
  produces(final_step) == [final_result];
  output_workflow(request_routing) == [final_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(classify_step) == classifier;
  step_executor(primary_handler_step) == primary_agent;
  step_executor(fallback_handler_step) == fallback_agent;
  step_executor(final_step) == final_agent;

  -- STEP CONFIGURATION
  step_name(classify_step) == classify_name;
  step_instruction(classify_step) == classify_instruction;
  step_name(primary_handler_step) == primary_handler_name;
  step_instruction(primary_handler_step) == primary_handler_instruction;
  step_name(fallback_handler_step) == fallback_handler_name;
  step_instruction(fallback_handler_step) == fallback_handler_instruction;
  step_name(final_step) == final_name;
  step_instruction(final_step) == final_instruction;

  -- AGENT CONFIGURATION
  agent_config(classifier, default_model, default_engine, default_api);
  agent_config(primary_agent, default_model, default_engine, default_api);
  agent_config(fallback_agent, default_model, default_engine, default_api);
  agent_config(final_agent, default_model, default_engine, default_api);
}
```