```fusionflow
-- SCENARIO: score-based routing with eager branch execution
-- AUTHORED: 2025-03-11 from intent: "score >= 80 select accept, else review"

const request: Artifact;
const score: Artifact;
const accept_result: Artifact;
const review_result: Artifact;
const selected_result: Artifact;
const final_result: Artifact;

const scoring: Step;
const accept_handler: Step;
const review_handler: Step;
const final_step: Step;

const scoring_name: StepName;
const accept_name: StepName;
const review_name: StepName;
const final_name: StepName;

const scoring_instruction: Instruction;
const accept_instruction: Instruction;
const review_instruction: Instruction;
const final_instruction: Instruction;

const scoring_agent: Agent, Executor;
const accept_agent: Agent, Executor;
const review_agent: Agent, Executor;
const final_agent: Agent, Executor;

const default_model: Model;
const default_engine: Engine;
const default_api: ApiBase;

workflow request_handler {
  -- DATA FLOW
  input_workflow(request_handler) == [request];
  consumes(scoring) == [request];
  produces(scoring) == [score];
  consumes(accept_handler) == [request];
  produces(accept_handler) == [accept_result];
  consumes(review_handler) == [request];
  produces(review_handler) == [review_result];
  selected_result == if(score >= 80, accept_result, review_result);
  consumes(final_step) == [selected_result];
  produces(final_step) == [final_result];
  output_workflow(request_handler) == [final_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(scoring) == scoring_agent;
  step_executor(accept_handler) == accept_agent;
  step_executor(review_handler) == review_agent;
  step_executor(final_step) == final_agent;

  -- STEP CONFIGURATION
  step_name(scoring) == scoring_name;
  step_instruction(scoring) == scoring_instruction;
  step_name(accept_handler) == accept_name;
  step_instruction(accept_handler) == accept_instruction;
  step_name(review_handler) == review_name;
  step_instruction(review_handler) == review_instruction;
  step_name(final_step) == final_name;
  step_instruction(final_step) == final_instruction;

  -- AGENT CONFIGURATION
  agent_config(scoring_agent, default_model, default_engine, default_api);
  agent_config(accept_agent, default_model, default_engine, default_api);
  agent_config(review_agent, default_model, default_engine, default_api);
  agent_config(final_agent, default_model, default_engine, default_api);
}
```