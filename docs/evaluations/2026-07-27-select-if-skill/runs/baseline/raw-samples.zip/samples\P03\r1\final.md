```fusionflow
-- SCENARIO: request scoring with conditional accept-or-review routing
-- AUTHORED: 2025-01-15 from intent: "score request, route to accept when score >= 80, else route to review, finalize"

const request: Artifact;
const score: Artifact;
const accept_result: Artifact;
const review_result: Artifact;
const final_result: Artifact;

const scoring_step: Step;
const accept_handler: Step;
const review_handler: Step;
const final_step: Step;

const scoring_name: StepName;
const accept_name: StepName;
const review_name: StepName;
const final_name: StepName;

const scoring_instruction: Instruction;
const accept_instruction: Instruction;
const review_instruction: Instruction;
const final_instruction: Instruction;

const scoring_agent: Agent, Executor;
const accept_agent: Agent, Executor;
const review_agent: Agent, Executor;
const final_agent: Agent, Executor;

const scoring_model: Model;
const engine: Engine;
const api: ApiBase;
const low_effort: ReasoningEffort;
const read_tool: Tool;

workflow request_scoring {
  -- DATA FLOW
  input_workflow(request_scoring) == [request];
  consumes(scoring_step) == [request];
  produces(scoring_step) == [score];
  consumes(accept_handler) == [request];
  produces(accept_handler) == [accept_result];
  consumes(review_handler) == [request];
  produces(review_handler) == [review_result];
  consumes(final_step) == [if(score >= 80, accept_result, review_result)];
  produces(final_step) == [final_result];
  output_workflow(request_scoring) == [final_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(scoring_step) == scoring_agent;
  step_executor(accept_handler) == accept_agent;
  step_executor(review_handler) == review_agent;
  step_executor(final_step) == final_agent;

  -- STEP CONFIGURATION
  step_name(scoring_step) == scoring_name;
  step_instruction(scoring_step) == scoring_instruction;
  step_timeout(scoring_step) == 300;
  max_attempts(scoring_step) == 2;
  step_name(accept_handler) == accept_name;
  step_instruction(accept_handler) == accept_instruction;
  step_timeout(accept_handler) == 300;
  max_attempts(accept_handler) == 2;
  step_name(review_handler) == review_name;
  step_instruction(review_handler) == review_instruction;
  step_timeout(review_handler) == 300;
  max_attempts(review_handler) == 2;
  step_name(final_step) == final_name;
  step_instruction(final_step) == final_instruction;

  -- WORKFLOW CONFIGURATION
  max_concurrency(request_scoring) == 3;
  workflow_timeout(request_scoring) == 900;

  -- AGENT CONFIGURATION
  agent_config(scoring_agent, scoring_model, engine, api);
  agent_config(accept_agent, scoring_model, engine, api);
  agent_config(review_agent, scoring_model, engine, api);
  agent_config(final_agent, scoring_model, engine, api);

  allowed_tool(scoring_agent, read_tool);
  allowed_tool(accept_agent, read_tool);
  allowed_tool(review_agent, read_tool);
  allowed_tool(final_agent, read_tool);
  reasoning_effort(scoring_agent) == low_effort;
}
```