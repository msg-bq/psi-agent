```fusionflow
-- SCENARIO: Route a request to one of three handlers based on triage flags
-- AUTHORED: 2025-07-16 from intent: "priority routing workflow with triage -> three parallel handlers -> conditional final step"

const request: Artifact;
const urgent_flag: Artifact;
const allowed_flag: Artifact;
const review_flag: Artifact;
const exception_flag: Artifact;
const primary_result: Artifact;
const review_result: Artifact;
const fallback_result: Artifact;
const final_result: Artifact;

const triage_step: Step;
const primary_handler_step: Step;
const review_handler_step: Step;
const fallback_handler_step: Step;
const final_step: Step;

const triage_name: StepName;
const primary_name: StepName;
const review_name: StepName;
const fallback_name: StepName;
const final_name: StepName;

const triage_instruction: Instruction;
const primary_instruction: Instruction;
const review_instruction: Instruction;
const fallback_instruction: Instruction;
const final_instruction: Instruction;

const triage_agent: Agent, Executor;
const primary_agent: Agent, Executor;
const review_agent: Agent, Executor;
const fallback_agent: Agent, Executor;
const final_agent: Agent, Executor;

const model: Model;
const engine: Engine;
const api: ApiBase;
const effort: ReasoningEffort;

workflow priority_routing {
  -- DATA FLOW
  input_workflow(priority_routing) == [request];
  consumes(triage_step) == [request];
  produces(triage_step) == [urgent_flag, allowed_flag, review_flag, exception_flag];
  consumes(primary_handler_step) == [request];
  produces(primary_handler_step) == [primary_result];
  consumes(review_handler_step) == [request];
  produces(review_handler_step) == [review_result];
  consumes(fallback_handler_step) == [request];
  produces(fallback_handler_step) == [fallback_result];
  consumes(final_step) == [
    if(
      (urgent_flag = True) AND (allowed_flag = True),
      primary_result,
      if(
        (review_flag = True) OR (exception_flag = True),
        review_result,
        fallback_result
      )
    )
  ];
  produces(final_step) == [final_result];
  output_workflow(priority_routing) == [final_result];

  -- EXECUTOR ASSIGNMENT
  step_executor(triage_step) == triage_agent;
  step_executor(primary_handler_step) == primary_agent;
  step_executor(review_handler_step) == review_agent;
  step_executor(fallback_handler_step) == fallback_agent;
  step_executor(final_step) == final_agent;

  -- STEP CONFIGURATION
  step_name(triage_step) == triage_name;
  step_instruction(triage_step) == triage_instruction;
  step_timeout(triage_step) == 120;
  max_attempts(triage_step) == 2;
  step_name(primary_handler_step) == primary_name;
  step_instruction(primary_handler_step) == primary_instruction;
  step_timeout(primary_handler_step) == 300;
  max_attempts(primary_handler_step) == 2;
  step_name(review_handler_step) == review_name;
  step_instruction(review_handler_step) == review_instruction;
  step_timeout(review_handler_step) == 300;
  max_attempts(review_handler_step) == 2;
  step_name(fallback_handler_step) == fallback_name;
  step_instruction(fallback_handler_step) == fallback_instruction;
  step_timeout(fallback_handler_step) == 300;
  max_attempts(fallback_handler_step) == 2;
  step_name(final_step) == final_name;
  step_instruction(final_step) == final_instruction;
  step_timeout(final_step) == 120;
  max_attempts(final_step) == 1;

  -- WORKFLOW CONFIGURATION
  max_concurrency(priority_routing) == 3;
  workflow_timeout(priority_routing) == 1200;

  -- AGENT CONFIGURATION
  agent_config(triage_agent, model, engine, api);
  agent_config(primary_agent, model, engine, api);
  agent_config(review_agent, model, engine, api);
  agent_config(fallback_agent, model, engine, api);
  agent_config(final_agent, model, engine, api);
  reasoning_effort(triage_agent) == effort;
  reasoning_effort(primary_agent) == effort;
  reasoning_effort(review_agent) == effort;
  reasoning_effort(fallback_agent) == effort;
  reasoning_effort(final_agent) == effort;
}
```